###### Codigos para partes de la libreria
### para introducir los datos
# metAb <- read.table("/Users/clararodriguezcasado/Dropbox/Doctorado/articulo1-metagenomica/matrices2013/4-Metagenomic Gut/Chrons_allCounts.csv", header=T, sep = ";", dec = ",")
# ### cambio los nombres de las columnas y de las filas , para anonimizar las muestras.
# names(metAb)<-c("Sample1","Sample2","Sample3","Sample4","Sample5","Sample6",
#                 "Sample7","Sample8","Sample9","Sample10","Sample11","Sample12",
#                 "Sample13","Sample14","Sample15","Sample16","Sample17","Sample18",
#                 "Sample19")
# devtools::use_data(metAb,overwrite = TRUE)

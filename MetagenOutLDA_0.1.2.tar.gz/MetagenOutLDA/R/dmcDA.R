#' dmcDA
#'
#' Function to caculate linear discriminant analysis
#' @param Matmet data-set matrix with data containing the mategenomic frequencies
#' @param Matbd data-set matrix with data containing the biodiversity Index
#' @param label_group label of the group (disease, health, etc)
#' @param method must be a list with the name of the differents methods we want.
#' @param lambda Lambda parameter for RRLDA analysis.
#' @param hp hp parameter for RRLDA analysis.
#' @param NameCoeff A vector with the names of the coefficients to be used in the analysis.
#' @param decay parameter for weight decay. Default 0.
#' @param maxit maximum number of iterations. Default 100.
#' @param tol indicates the tolerance for the selection of the variables in the models,
#' the default value is 0.0001 .
#' @return a list with the summarys of the selected clasification methods.
#' @export

#####################
## Analisis discriminante
#####################
dmcDA<-function(Matmet,Matbd,label_group,method=c("LDAcv","QDA","rrLDA","SVM"),lambda=0.2,
                hp=0.75,NameCoeff=c("B0","B1","B2","B3","Shannon","Simpson"),
                decay=0,maxit=100,tol=0.0001){
  Gps<-length(label_group) ## En esta variable se almacena el número de grupos para hacer los calculos de los porcentajes.
  Z<<-cbind(Matmet,Matbd)
  ## Convierto en data.frame la matriz
  ZZdat<-data.frame(Z)
  ZZdat$Group<-factor( ZZdat$Group,labels=label_group)
  ZZ<-ZZdat[names(ZZdat)%in%c(NameCoeff,"Group")]
  ncoef<-length(NameCoeff) ## numero de coeficientes que se quieren pasar a las funciones.
  ### Filtramos si alguno de ellos tiene todos los valores por debajo de la tolerancia:
  posCoef<-c()
  for(pcoef in 1:ncoef){
    datintCoef<-ZZ[names(ZZ)%in%c(NameCoeff[pcoef])]
    if(sum(abs(datintCoef)>tol)==0) posCoef<-c(posCoef,pcoef)
  }
  NamesCoef2<-NameCoeff[-posCoef]
  # NamesCoef2
  ### Los datos sin esa variable seran:
  ZZ<-ZZ[names(ZZ)%in%c(NamesCoef2,"Group")]
  Posiciones<-which(names(ZZ)%in%NameCoeff)
  salida<-list()
  cont<-1## contador de la posicion de la lista de resultados que se debe exportar
  if("LDA"%in%method){
    ##########################################################################################
    ######         LDA with all the variables.
    ##########################################################################################
    fitLDA <- lda(Group ~ ., data = ZZ,CV=F, method="moment") #sin leave on out
    lda.values <- predict(fitLDA)
    ctLDA <- table(ZZ$Group, predict(fitLDA)$class)
    confusionMatrix(ctLDA)
    salida[[cont]]<-list(model=fitLDA,predictVal=lda.values,tabClas=ctLDA,summaryClas=confusionMatrix(ctLDA))
    names(salida)[cont]<-"LDA without CV"
    cont<-cont+1
  }
  if("LDAcv"%in%method){
    ##########################################################################################
    ######         LDA with all the variables.With CV
    ##########################################################################################
    fitLDA.cv <- lda(Group ~ ., data = ZZ,CV=TRUE, method="moment") #sin leave on out
    ctLDA.cv <- table(ZZ$Group, fitLDA.cv$class)
    confusionMatrix(ctLDA.cv)
    salida[[cont]]<-list(model=fitLDA.cv,tabClas=ctLDA.cv,summaryClas=confusionMatrix(ctLDA.cv))
    names(salida)[cont]<-"LDA with CV"
    cont<-cont+1
  }
  if("QDA"%in%method){
    ##########################################################################################
    ######         Quadratic Discriminant Analysis without CV
    ##########################################################################################
    fit.qda <- qda( Group ~ ., data = ZZ,
                    na.action="na.omit", CV=F)
    ctQDA <- table(ZZ$Group, predict(fit.qda)$class)
    confusionMatrix(ctQDA)
    salida[[cont]]<-list(model=fit.qda,tabClas=ctQDA,summaryClas=confusionMatrix(ctQDA))
    names(salida)[cont]<-"QDA"
    cont<-cont+1
  }
  if("rrLDA"%in%method){
    ##########################################################################################
    ######         Robust Regularized Linear Discriminant Analysis
    ##########################################################################################
    x<-ZZ[,Posiciones]
    rr.lda <- rrlda(x, grouping=as.numeric(ZZ$Group), lambda=lambda, hp=hp) ## perform rrlda
    pred <- predict(rr.lda, x) ## predict
    tablaClas<-table(as.numeric(pred$class), as.numeric(ZZ$Group)) ## show errors
    rownames(tablaClas)<-label_group
    colnames(tablaClas)<-label_group
    confusionMatrix(tablaClas)
    salida[[cont]]<-list(model=rr.lda,predictVal=pred,tabClas=tablaClas,summaryClas=confusionMatrix(tablaClas))
    names(salida)[cont]<-"RRLDA"
    cont<-cont+1
  }
  if("mda"%in%method){
    ##########################################################################################
    ######         mda
    ##########################################################################################
    fit.mda <- mda(Group ~ ., data = ZZ)
    predictions <- predict(fit.mda, ZZ[,Posiciones])
    # summarize accuracy
    Tab.mda<-table(predictions, ZZ$Group)
    confusionMatrix(Tab.mda)
    salida[[cont]]<-list(model=fit.mda,predictVal=predictions,tabClas=Tab.mda,summaryClas=confusionMatrix(Tab.mda))
    names(salida)[cont]<-"MDA"
    cont<-cont+1
  }
  if("SVM"%in%method){
    ##########################################################################################
    ######         support vector machine
    ##########################################################################################
    fit.kern <- ksvm(Group ~ ., data = ZZ)
    predictions <- predict(fit.kern, ZZ[,Posiciones], type="response")
    Tab.kern<-table(predictions, ZZ$Group)
    confusionMatrix(Tab.kern)
    salida[[cont]]<-list(model=fit.kern,predictVal=predictions,tabClas=Tab.kern,summaryClas=confusionMatrix(Tab.kern))
    names(salida)[cont]<-"SVM"
    cont<-cont+1
  }
  return(salida)
}

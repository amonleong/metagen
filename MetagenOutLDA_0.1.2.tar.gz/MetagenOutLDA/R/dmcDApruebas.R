

#####################
## Analisis discriminante
#####################
dmcDA<-function(Matmet,Matbd,label_group){
  Y<<-cbind(Matmet,Matbd)
  ## Convierto en data.frame la matriz
  YY<-data.frame(Y)
  YY$Group<-factor( YY$Group,labels=label_group)
  #############################################################
  ### Linear Discriminant Analysis with Jacknifed Prediction
  #############################################################
  ### LDA with all the variables, without prior.
  # resultadosLDA<-list()
  # fit <- lda(Group ~ B0 + B1 + B2 + B3 +Shannon + Simpson, data = YY,CV=FALSE, method="moment") #sin leave on out
  # resultadosLDA$fit<-fit
  # resultadosLDA$prediction<-predict(fit)
  # tab1<-table(predict(fit)$class, YY$Group)
  # resultadosLDA$TabClas<-tab1
  # predict(fit)$class
  # resultadosLDA$ClassRate<-misclassification.rate(tab1) #tabla para saber si estan bien o mal clasificado
  #
  #
  # # Scatter plot using the 1st two discriminant dimensions
  # # plot(fit) # fit from lda
  # # resultadosLDA$graf<-plot(fit)
  # resultadosLDA$TabProp<-prop.table(tab1, 1)
  # diag(prop.table(tab1))
  # # total percent correct
  # resultadosLDA$PropCorrectClass<-sum(diag(prop.table(tab1))) #mira el % de bien clasificados
  # return(resultadosLDA)
  # Exploratory Graph for LDA or QDA
  # library(klaR)
  # partimat(Group ~ B0 + B1 + B2 + B3 , data = YY, method="lda")

  ### LDA with all the variables.
  fit <- lda(Group ~ B0 + B1 + B2 + B3 +Shannon + Simpson, data = YY,CV=F, method="moment") #sin leave on out
  lda.values <- predict(fit)
  ldahist(data = lda.values$x[,1], g=YY$Group)
  ct <- table(YY$Group, predict(fit)$class)
  ct
  diag(prop.table(ct, 1))#good classification
  sum(diag(prop.table(ct))) #94% (depende de como ha ido)

  ### LDA with all the variables, with CV.
  fit <- lda(Group ~ B0 + B1 + B2 + B3 +Shannon + Simpson, data = YY,CV=TRUE, method="moment") #sin leave on out
  ct <- table(YY$Group, fit$class)
  ct
  diag(prop.table(ct, 1))
  # total percent correct
  sum(diag(prop.table(ct)))


  # Quadratic Discriminant Analysis with 3 groups applying
  # resubstitution prediction and equal prior probabilities.
  fit.c <- qda( Group ~ B0 + B1 + B2 + B3 +Shannon + Simpson, data = YY,
                na.action="na.omit", CV=F)
  fit.c
  ct <- table(YY$Group, predict(fit.c)$class)
  ct
  diag(prop.table(ct, 1))
  # total percent correct
  sum(diag(prop.table(ct)))

  ##### Random Forest

  # set.seed(715)
  # ii.rf <- randomForest(Group ~ B0 + B1 + B2 + B3 +Shannon + Simpson, data = YY, importance=TRUE,
  #                       proximity=TRUE, norm.votes=FALSE, ntree=5000)
  # print(ii.rf)
  # ## Look at variable importance:
  # round(importance(ii.rf), 2)

  #Robust Regularized Linear Discriminant Analysis
  #using in the current example of diatomeas
  library(rrlda)
  x<-YY[,c(1:4,15,16)]
  rr <- rrlda(x, grouping=as.numeric(YY$Group), lambda=0.2, hp=0.75) ## perform rrlda
  pred <- predict(rr, x) ## predict
  tablaClas<-table(as.numeric(pred$class), as.numeric(YY$Group)) ## show errors
  salida<-c(tablaClas[1,1]/sum(tablaClas[1,1]+tablaClas[1,2]),
            tablaClas[2,2]/sum(tablaClas[2,1]+tablaClas[2,2]))
  salida
  sum(tablaClas[1,1]+tablaClas[2,2])/19

  #otros metodos de clasificacion en: http://machinelearningmastery.com/non-linear-classification-in-r/
  #Plot for Flexible Discriminant Analysis
  #Package:   mda
  #Plot in discriminant (canonical) coordinates a fda or (by inheritance) a mda object.
  library(mda)
  fit <- mda(Group ~ B0 + B1 + B2 + B3 +Shannon + Simpson, data = YY)
  # summarize the fit
  summary(fit)
  # make predictions
  predictions <- predict(fit, YY[,c(1:4,15,16)])
  # summarize accuracy
  table(predictions, YY$Group)
  (7+11)/19
  7/7
  11/12

  #neural nets
  library(nnet)
  # fit model
  fit <- nnet(Group ~ B0 + B1 + B2 + B3 +Shannon + Simpson, data = YY, size=4, decay=0.0001, maxit=500)
  # summarize the fit
  summary(fit)
  # make predictions
  predictions <- predict(fit, YY[,c(1:4,15,16)], type="class")
  # summarize accuracy
  table(predictions, YY$Group)
  (9+18+8)/35 #88.6

  #support vector machine
  library(kernlab)
  # fit model
  fit <- ksvm(Group ~ B0 + B1 + B2 + B3 +Shannon + Simpson, data = YY)
  # summarize the fit
  summary(fit)
  # make predictions
  predictions <- predict(fit, YY[,c(1:4,15,16)], type="response")
  # summarize accuracy
  table(predictions, YY$Group)
  (4+10)/19
  4/7
  10/12
}

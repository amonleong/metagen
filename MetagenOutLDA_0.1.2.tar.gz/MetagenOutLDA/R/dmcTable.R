#' dmcTable
#'
#' Function to caculate linear discriminant analysis
#' @param Matmet data-set matrix with data containing the mategenomic frequencies.This matrix must have a variable
#' called Group indicating the group.
#' @param Matbd data-set matrix with data containing the biodiversity Index
#' @param label_group label of the group (disease, health, etc)
#' @param lambda Lambda parameter for RRLDA analysis.
#' @param hp hp parameter for RRLDA analysis.
#' @param NameCoeff A vector with the names of the coefficients to be used in the analysis.
#' @param decay parameter for weight decay. Default 0.
#' @param maxit maximum number of iterations. Default 100.
#' @param tol indicates the tolerance for the selection of the variables in the models,
#' the default value is 0.0001 .
#' @return a table
#' @export


#####################
## Resultados analisis discriminante
#####################
dmcTable<-function(Matmet,Matbd,label_group,lambda=0.2,hp=0.75,NameCoeff=c("B0","B1","B2","B3","Shannon","Simpson"),
                   decay=0,maxit=100,tol=0.0001){
  Gps<-length(label_group) ## En esta variable se almacena el número de grupos para hacer los calculos de los porcentajes.
  Z<<-cbind(Matmet,Matbd)
  ## Convierto en data.frame la matriz
  ZZdat<-data.frame(Z)
  ZZdat$Group<-factor( ZZdat$Group,labels=label_group)
  ZZ<-ZZdat[names(ZZdat)%in%c(NameCoeff,"Group")]
  ncoef<-length(NameCoeff) ## numero de coeficientes que se quieren pasar a las funciones.
  ### Filtramos si alguno de ellos tiene todos los valores por debajo de la tolerancia:
  posCoef<-c()
  for(pcoef in 1:ncoef){
    datintCoef<-ZZ[names(ZZ)%in%c(NameCoeff[pcoef])]
    if(sum(abs(datintCoef)>tol)==0) posCoef<-c(posCoef,pcoef)
  }
  if(is.null(posCoef)){
    NamesCoef2<-NameCoeff
  }
  if(!is.null(posCoef)){
    NamesCoef2<-NameCoeff[-posCoef]
  }
  ### Los datos sin esa variable seran:
  ZZ<-ZZ[names(ZZ)%in%c(NamesCoef2,"Group")]
  ##########################################################################################
  ######         LDA with all the variables.
  ##########################################################################################
  fitLDA <- lda(Group ~ ., data = ZZ,CV=F, method="moment") #sin leave on out
  lda.values <- predict(fitLDA)
  # ldahist(data = lda.values$x[,1], g=ZZ$Group)
  ctLDA <- table(ZZ$Group, predict(fitLDA)$class)
  confusionMatrix(ctLDA)
  # diag(prop.table(ctLDA, 1))#good classification
  # sum(diag(prop.table(ctLDA))) #94% (depende de como ha ido)
  salida<-data.frame(Method="LDA without CV",t(diag(prop.table(ctLDA, 1))),Total=sum(diag(prop.table(ctLDA))))
  ##########################################################################################
  ######         LDA with all the variables.With CV
  ##########################################################################################
  fitLDA.cv <- lda(Group ~ ., data = ZZ,CV=TRUE, method="moment") #sin leave on out
  ctLDA.cv <- table(ZZ$Group, fitLDA.cv$class)
  # diag(prop.table(ctLDA.cv, 1))
  # total percent correct
  # sum(diag(prop.table(ctLDA.cv)))
  confusionMatrix(ctLDA.cv)
  salida<-rbind(salida,
                data.frame(Method="LDA with CV",t(diag(prop.table(ctLDA.cv, 1))),Total=sum(diag(prop.table(ctLDA.cv)))))

  ##########################################################################################
  ######         Quadratic Discriminant Analysis without CV
  ##########################################################################################
  fit.qda <- qda( Group ~ ., data = ZZ,
                na.action="na.omit", CV=F)
  ctQDA <- table(ZZ$Group, predict(fit.qda)$class)
  # diag(prop.table(ctQDA, 1))
  # # total percent correct
  # sum(diag(prop.table(ctQDA)))
  salida<-rbind(salida,
                data.frame(Method="QDA without CV",t(diag(prop.table(ctQDA, 1))),Total=sum(diag(prop.table(ctQDA)))))
  ##########################################################################################
  ######         Robust Regularized Linear Discriminant Analysis
  ##########################################################################################
  Posiciones<-which(names(ZZ)%in%NameCoeff)

  x<-ZZ[,Posiciones]
  rr <- rrlda(x, grouping=as.numeric(ZZ$Group), lambda=lambda, hp=hp) ## perform rrlda
  pred <- predict(rr, x) ## predict
  tablaClas<-table(as.numeric(pred$class), as.numeric(ZZ$Group)) ## show errors
  rownames(tablaClas)<-label_group
  colnames(tablaClas)<-label_group
  salida<-rbind(salida,
                data.frame(Method="RRLDA",t(diag((prop.table(tablaClas,1)))),
                           Total= sum(diag(prop.table(tablaClas)))))
  #otros metodos de clasificacion en: http://machinelearningmastery.com/non-linear-classification-in-r/
  #Plot for Flexible Discriminant Analysis
  #Package:   mda
  #Plot in discriminant (canonical) coordinates a fda or (by inheritance) a mda object.
  ##########################################################################################
  ######         mda
  ##########################################################################################
  fit.mda <- mda(Group ~ ., data = ZZ)
  # summarize the fit
  # summary(fit.mda)
  # make predictions
  predictions <- predict(fit.mda, ZZ[,Posiciones])
  # summarize accuracy
  Tab.mda<-table(predictions, ZZ$Group)
  salida<-rbind(salida,
                data.frame(Method="mda",t(diag((prop.table(Tab.mda,1)))),
                           Total= sum(diag(prop.table(Tab.mda)))))
  ##########################################################################################
  ######         neural nets
  ##########################################################################################
  #
  # library(nnet)
  # # fit model
  # fit <- nnet(Group ~ ., data = ZZ, size=4, decay=decay, maxit=maxit)
  # # summarize the fit
  # summary(fit)
  # # make predictions
  # predictions <- predict(fit, ZZ[,Posiciones], type="class")
  # # summarize accuracy
  # Tab.nnet<-table(predictions, ZZ$Group)
  # table(predictions,factor(ZZ$Group,levels=levels(ZZ$Group)))
  # salida<-rbind(salida,
  #               data.frame(Method="nnet",t(diag((prop.table(Tab.nnet,1)))),
  #                          Total= sum(diag(prop.table(Tab.nnet)))))
  ##########################################################################################
  ######         support vector machine
  ##########################################################################################
  #
  # fit model
  fit.kern <- ksvm(Group ~ ., data = ZZ)
  # summarize the fit
  # summary(fit.kern)
  # make predictions
  predictions <- predict(fit.kern, ZZ[,Posiciones], type="response")
  # summarize accuracy
  Tab.kern<-table(predictions, ZZ$Group)
  salida<-rbind(salida,
                data.frame(Method="Support Vector Machine",t(diag((prop.table(Tab.kern,1)))),
                           Total= sum(diag(prop.table(Tab.kern)))))
  return(salida)
}

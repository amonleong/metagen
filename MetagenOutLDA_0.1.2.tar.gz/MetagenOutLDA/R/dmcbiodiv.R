#' dmcbiodiv
#'
#' Function to caculate a profile of a metagenomic distribution
#' @param Mat data-set matrix with data containing the mategenomic frequencies
#' @param order if TRUE the matrix is ordered
#' @param index are the index that are going to be calculated
#' @return a matrix
#' @export

dmcbiodiv<-function(Mat,order = TRUE,index=c("shannon","simpson")){

  num_var<-ncol(Mat)
  num_ind<-nrow(Mat)
  ### Se ordena la matriz de forma descendente por columnas, a menos que el
  ### parametro order se ponga a FALSE.

  if (order) {
    for (i in 1: num_var) {
      Mat[,i] <- Mat[order(-Mat[,i]),i] #ORDEN DESCENCENTE para la columna i de la matriz(Mat)
    }
  }

  ### CREAR LA VARIABLE ESPECIE (EJE DE LAS Y) :
  ### especie 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,...

  Mat$especie <- c(1:num_ind)
  #####################
  ## Calculo de los indices de biodiversidad (alfa y beta)-frecuencias
  #####################
  #biodiversidad alfa
  Shannon<-rep(NA,num_var)
  Simpson<-rep(NA,num_var)
  InvSimpson<-rep(NA,num_var)
  for (i in 1: num_var) {
    vector_ind <- na.omit(2^Mat[,i])
    Shannon[i]<- diversity(vector_ind, index = "shannon")    #shannon
    Simpson[i]<- diversity(vector_ind, index = "simpson")    #simpson
    InvSimpson[i]<- diversity(vector_ind, index = "invsimpson")    #invsimpson
  }
  Z<<-c()
  ###  Shannon
  if("shannon"%in%index) Z<<-cbind(Z,Shannon)
  if("simpson"%in%index) Z<<-cbind(Z,Simpson)
  if("invsimpson"%in%index) Z<<-cbind(Z,InvSimpson)

  #biodiversidad beta
  #clara mirar: biodiversidad beta
  #distancia de Bray-curtis, distancia de Camberra, Unifrac, weighted-unifrac, distancia de jaccard
  # NMDS : non parametric multidmensional scaling, coordenadas canonicas

  return(Z)
}

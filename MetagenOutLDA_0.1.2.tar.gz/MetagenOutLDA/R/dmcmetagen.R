#############################################################
######  Codigo para crear la función dmcmetagen
######        V2. 25-01-2016
######       Clara R. C.
#############################################################

misclassification.rate=function(tab){
  num1=sum(diag(tab))
  denom1=sum(tab)
  signif(1-num1/denom1,3)
}

#########################################################
##########   Función para crear los perfiles   ##########
#########################################################

#' dmcmetagen
#'
#' Function to calculate a profile of a metagenomic distribution
#' @param Mat data-set matrix with data containing the mategenomic frequencies
#' @param regres_type type of regresion (linear, cubic)
#' @param group Is the group
#' @param label_group label of the group (disease, health, etc)
#' @param print if you want to print the figures
#' @param ajust true if we want to adjust
#' @param robust if TRUE the IC calculated are robust.
#' @param order if TRUE the matrix is ordered
#' @param graphTitle an optional title
#' @param conf_int indicates the confidence for the intervals.
#' @return a graph and harmonics
#' @export
dmcmetagen<-function(Mat,regres_type,group,label_group,conf_int=0.95,
                     printGrups=TRUE,print=FALSE, ajust=TRUE, robust = TRUE,
                     order = TRUE,graphTitle="",tol=0.1){

  ### La función recibe una matriz que contiene en las columnas los diferentes
  ### "muestreos" y en las filas las diferentes especies. Estos números se
  ### almacenan en variables que emplearemos más tarde.

  num_var<-ncol(Mat)
  num_ind<-nrow(Mat)
  num_groups<-length(levels(as.factor(group)))
  ### Se ordena la matriz de forma descendente por columnas, a menos que el
  ### parametro order se ponga a FALSE.

  if (order) {
    for (i in 1: num_var) {
      Mat[,i] <- Mat[order(-Mat[,i]),i] #ORDEN DESCENCENTE para la columna i de la matriz(Mat)
    }
  }

  ### CREAR LA VARIABLE ESPECIE (EJE DE LAS Y) :
  ### especie 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,...

  Mat$especie <- c(1:num_ind)

  ### Representación gráfica si el parámetro print=TRUE

  if (print) {
    plot(Mat[ ,1]~especie, data = Mat, ylab="Log2(Frequency)", ylab="Specie(Hits)", col = 0)
    for (i in 1: num_var) {
      #representacion de la grafica para todos los datos
      par(new=T)
      plot(Mat[ ,i]~especie, data = Mat, xlab="", ylab="",
           type="l", lty = 7, col = group[i]+1,main=graphTitle,yaxt="n",xaxt="n")
    }
  }

  if(printGrups){
    ngroup<-1
    par(mfrow=c(num_groups,1))
    for(i in names(table(group))){
      datint<-Mat[,group==i]
      datint$especie<-Mat$especie
      plot(Mat[ ,1]~especie, data = Mat, ylab="Log2(Frequency)", xlab="Specie(Hits)", col = 0)
      for (j in 1:(dim(datint)[2]-1)) {
        par(new=T)
        plot(datint[ ,j]~especie, data = datint, xlab="", ylab="",
             type="l", lty = 7, col = as.numeric(i)+1,yaxt="n",xaxt="n")
      }
      title(paste(label_group[ngroup]))
      ngroup<-ngroup+1
    }
  }


  ### Regresion lineal (regres_type==1)
  ### Se calculan los coeficientes si el tipo de regresión elegido es: lineal.
  if (regres_type ==1) {
    #Regresion lineal y = Betao + Beta1*x
    #definicion de la matriz RES:
    RES <<- matrix(NA, num_var, 8) #columna, fila   AHORA ES VARIABLE GLOBAL
    #Calculos de regresion modelo lineal todos los individuos sanos
    for (i in 1: num_var) {
      periodo_sano_model.lineal <- lm( especie ~ x[ ,i], data = Mat)
      #Obtenim el summary del model: Multiple R-squared; Adjusted R-squared i F-statistic
      #summary(periodo_sano_lineal)
      a_confint<-confint(periodo_sano_model.lineal,level=conf_int) #intervalos de confianza de la estimacion coef
      a_coef<- coef(periodo_sano_model.lineal) #estimacion de coeficientes
      #terminos independientes:
      RES[i,1] <<- a_coef[1] #termino independiente (BO)
      RES[i,2] <<- a_confint[1,1] #termino independiente (BO) extremo 2.5%
      RES[i,3] <<- a_confint[1,2] #termino independiente (BO) extremo 97.5%
      #pendientes:
      RES[i,4] <<- a_coef[2] #coeficiente B1
      RES[i,5] <<- a_confint[2,1] #coeficiente B1 extremo 2.5%
      RES[i,6] <<- a_confint[2,2] #coeficiente B1 extremo 97.5%
      #R^2 (Bondad de ajuste del modelo):
      RES[i,7] <<- summary(periodo_sano_model.lineal)$r.squared #R^2
      RES[i,8] <<- group[i]
    }

    #RES
    ## Le pongo nombres a la matriz RES
    colnames(RES)<<-c("B0",paste("ICB0",conf_int*100,"%inf",sep=""),
                    paste("ICB0",conf_int*100,"%sup",sep=""),
                    "B1",paste("ICB1",conf_int*100,"%inf",sep=""),
                    paste("ICB1",conf_int*100,"%sup",sep=""),
                    "R^2","Group")

    ## boxplot(RES[,4],RES[,5], RES[,6] ) #boxplots de los B1 lineales Y SU CI95%
    # plot(weightgain ~ initial.wt, pch=ifelse(treatment=="standard",1,16), data=goats)
    # par(op)

    #intervalo de confianza para la media parametro Bo
    a<- t.test(RES[,1], conf.level=conf_int)
    aa <- a$conf.int #CI95%
    est_aa <- a$estimate #Mean
    ## Si los resultados son con intervalos robustos -->robust==TRUE
    if (robust){
      #intervalos de confianza robustos ----------------------------------------
      #library(simpleboot) #otra manera robusta de encontrar el intervalo de confianza
      # 20% trimmed mean bootstrap
      # articulo de http://stats.stackexchange.com/questions/16516/how-can-i-calculate-the-confidence-interval-of-a-mean-in-a-non-normally-distribu
      b1 <- one.boot(RES[,1], mean, R=2000, tr=.2)
      est_aa<-b1$t0 #media
      sdf <- boot.ci(b1, type=c("perc", "bca"),conf=conf_int)
      #names(sdf)
      ## sdf$percent[4:5] #intervalo de confianza 95% percent
      aa<-sdf$bca[4:5] #intervalo de confianza 95% percent, m?s estrecho y robusto
      RES[i,2] <<- sdf$bca[4] #termino independiente (BO) extremo 2.5% del intervalo robusto
      RES[i,3] <<- sdf$bca[5] #termino independiente (BO) extremo 97.5% del intervalo robusto
    }

    #intervalo de confianza para la media parametro B1
    b<- t.test(RES[,4], conf.level=conf_int)
    bb <- b$conf.int #CI95%
    est_bb <- b$estimate #Mean
    #decidir si los resultados son con intervalos robustos o no
    if (robust){
      b1 <- one.boot(RES[,4], mean, R=2000, tr=.2)
      est_bb<-b1$t0 #media
      sdf <- boot.ci(b1, type=c("perc", "bca"),conf=conf_int)
      bb<-sdf$bca[4:5] #intervalo de confianza 95% percent, m?s estrecho y robusto
      RES[i,5] <<- sdf$bca[4] #termino independiente (B1) extremo 2.5% del intervalo robusto
      RES[i,6] <<- sdf$bca[5] #termino independiente (B1) extremo 97.5% del intervalo robusto
    }

    #R^2
    #     c<- t.test(RES[,7], conf.level=0.95)
    #     cc <- c$conf.int #CI95%
    #     est_cc <- c$estimate #Mean
    #     if (robust){
    #      b1 <- one.boot(RES[,7], mean, R=2000, tr=.2)
    #       est_cc<-b1$t0 #media
    #       sdf <- boot.ci(b1, type=c("perc", "bca"))
    #       cc<-sdf$bca[4:5] #intervalo de confianza 95% percent, m?s estrecho y robusto
    #     }

    #IMPRIMIR CURVA
    #curve(est_aa + est_bb*(x),add=T, col = "purple")

    #     out <- list( 'LINNEAR REGRESSION #####(y = Beta_o + Beta_1*X) ############################',
    #                  'Beta_o ######(Media e IC95%)#######################################',
    #                  est_aa, aa,
    #                  'Beta_1 #######Media e IC95%) ######################################',
    #                  est_bb, bb,
    #                  'Coeficiente de determinaci?n R^2',
    #                  est_cc, cc)
    #     class(out) <- 'myclass'
    #     return(out)
    if(robust) colnames(RES)<<-c("B0",paste("ICrobustB0",conf_int*100,"%inf",sep=""),
                               paste("ICrobustB0",conf_int*100,"%sup",sep=""),
                               "B1",paste("ICrobustB1",conf_int*100,"%inf",sep=""),
                               paste("ICrobustB1",conf_int*100,"%sup",sep=""),"R^2","Group")

  }
  #########################################################################################
  #########################        Regresion cubica       #################################
  #########################################################################################
  if (regres_type ==2) {
    #2) Modelo CUBICO (y ~ Beta_0 + Beta_1 * x + Beta_2 * x^2 + Beta_3 * x^3

    ## nota tecnica. https://stat.ethz.ch/pipermail/r-help/2006-June/107606.html

    #definicion de la matriz RES:
    RES <<- matrix(NA, num_var, 14)

    ########## REAL Non-Linear Regression ##########
    # In order to 'really' do those regressions, you need to load the correct library (nls2) and use
    # the correct function(nls) or function(nls2) which is an updated version (Non-linear Least Squares [nls]).
    #
    # When using this function; you will need to known the formula for the model you are attempting
    # to apply.


    #Calculos de regresion modelo lineal todos los individuos sanos
    for (i in 1: num_var) {
      #periodo_sano_model.lineal <- lm( especie ~ x[ ,i], data = x)
      xx <- Mat[ ,i]
      yy<- Mat$especie
      #nls(y ~ a*x^b, start = list(a = a1, b = b1), control = list(maxiter = 500))
      #res.model <- nls2(yy ~  b*(xx^a), start = list(b = 0, a = 0), control = list(maxiter = 500), trace = TRUE)
      ##res.model <- nls2(yy ~ Const.inicial + b*(xx^a), start = list(Const.inicial = 600, b = -80, a = 1), control = list(maxiter = 500), trace = TRUE)
      # res.model <- lm(especie ~ Mat[,i] + I(Mat[,i]^2) + I(Mat[,i]^3), data = Mat)
      res.model <- lm(Mat[,i] ~ especie + I(especie^2) + I(especie^3), data = Mat)
      betas<-coef(res.model)
      smr<-summary(res.model)
      #terminos independientes:
      RES[i,1] <<- betas[1] #Beta_0
      RES[i,2] <<- betas[2] #Beta_1
      RES[i,3] <<- betas[3] #Beta_2
      RES[i,4] <<- betas[4] #Beta_3
      RES[i,5] <<- smr$r.squared[1] #R^2
      RES[i,6] <<- confint(res.model,level=conf_int)[1,1]
      RES[i,7] <<- confint(res.model,level=conf_int)[1,2]
      RES[i,8] <<- confint(res.model,level=conf_int)[2,1]
      RES[i,9] <<- confint(res.model,level=conf_int)[2,2]
      RES[i,10] <<- confint(res.model,level=conf_int)[3,1]
      RES[i,11] <<- confint(res.model,level=conf_int)[3,2]
      RES[i,12] <<- confint(res.model,level=conf_int)[4,1]
      RES[i,13] <<- confint(res.model,level=conf_int)[4,2]
      RES[i,14] <<- group[i]
    }

    ## boxplot(RES[,4],RES[,5], RES[,6] ) #boxplots de los B1 lineales Y SU CI95%



    #intervalo de confianza para la media parametro Betao
    a<- t.test(RES[,1], conf.level=conf_int)
    aa <- a$conf.int #CI95%
    est_aa <- a$estimate #Mean
    #decidir si los resultados son con intervalos robustos o no
    if (robust){
      b1 <- one.boot(RES[,1], mean, R=2000, tr=.2)
      est_aa<-b1$t0 #media
      sdf <- boot.ci(b1, type=c("perc", "bca"),conf=conf_int)
      #names(sdf)
      sdf$percent[4:5] #intervalo de confianza 95% percent
      aa<-sdf$bca[4:5] #intervalo de confianza 95% percent, m?s estrecho y robusto
      RES[i,6] <<- sdf$bca[4]
      RES[i,7] <<- sdf$bca[5]
    }

    #intervalo de confianza para la media parametro Beta1
    b<- t.test(RES[,2], conf.level=conf_int)
    bb <- b$conf.int #CI95%
    est_bb <- b$estimate #Mean
    #decidir si los resultados son con intervalos robustos o no
    if (robust){
      b1 <- one.boot(RES[,2], mean, R=2000, tr=.2)
      est_bb<-b1$t0 #media
      sdf <- boot.ci(b1, type=c("perc", "bca"),conf=conf_int)
      bb<-sdf$bca[4:5] #intervalo de confianza 95% percent, m?s estrecho y robusto
      RES[i,8] <<- sdf$bca[4]
      RES[i,9] <<- sdf$bca[5]
    }

    #intervalo de confianza para la media parametro Beta2
    c<- t.test(RES[,3], conf.level=conf_int)
    cc <- c$conf.int #CI95%
    est_cc <- c$estimate #Mean
    #decidir si los resultados son con intervalos robustos o no
    if (robust){
      b1 <- one.boot(RES[,3], mean, R=2000, tr=.2)
      est_cc<-b1$t0 #media
      sdf <- boot.ci(b1, type=c("perc", "bca"),conf=conf_int)
      cc<-sdf$bca[4:5] #intervalo de confianza 95% percent, m?s estrecho y robusto
      RES[i,10] <<- sdf$bca[4]
      RES[i,11] <<- sdf$bca[5]
    }
    #intervalo de confianza para la media parametro Beta2
    d<- t.test(RES[,4], conf.level=conf_int)
    dd <- d$conf.int #CI95%
    est_dd <- d$estimate #Mean
    #decidir si los resultados son con intervalos robustos o no
    if (robust){
      b1 <- one.boot(RES[,4], mean, R=2000, tr=.2)
      est_dd<-b1$t0 #media
      sdf <- boot.ci(b1, type=c("perc", "bca"),conf=conf_int)
      dd<-sdf$bca[4:5] #intervalo de confianza 95% percent, m?s estrecho y robusto
      RES[i,12] <<- sdf$bca[4]
      RES[i,13] <<- sdf$bca[5]
    }

    #intervalo de confianza para la media parametro R^2
    e<- t.test(RES[,5], conf.level=conf_int)
    ee <- e$conf.int #CI95%
    est_ee <- e$estimate #Mean
    #decidir si los resultados son con intervalos robustos o no
    #     if (robust){
    #       b1 <- one.boot(RES[,5], mean, R=2000, tr=.2)
    #       est_ee<-b1$t0 #media
    #       boot.ci(b1, type=c("perc", "bca"))
    #       sdf <- boot.ci(b1, type=c("perc", "bca"))
    #       #names(sdf)
    #       sdf$percent[4:5] #intervalo de confianza 95% percent
    #       ee<-sdf$bca[4:5] #intervalo de confianza 95% percent, m?s estrecho y robusto
    #     }

    #out <- list('Beta_o', smr, aa,  est_aa)
    #return(out)
    #     out <- list( smr, names(smr), 'Modelo polinomial (y ~ Beta_0 + Beta_1 * x + Beta_2 * x^2 + Beta_3 * x^3############################',
    #                  'Beta_o ######(Media e IC95%)#######################################',
    #                  est_aa, aa,
    #                  'Beta_1 #######Media e IC95%) ######################################',
    #                  est_bb, bb,
    #                  'Beta_2 #######Media e IC95%) ######################################',
    #                  est_cc, cc,
    #                  'Beta_3 #######Media e IC95%) ######################################',
    #                  est_dd, dd,
    #                  'R^2 #######Media e IC95%) ######################################',
    #                  est_ee, ee)
    ##est_ee, ee, RES[,1], summary(RES[,1]), RES[,2], summary(RES[,2]))

    #     class(out) <- 'myclass'
    #     return(out)
    if(robust==FALSE) colnames(RES)<<-c("B0","B1","B2","B3","R^2",
                    paste("ICB0",conf_int*100,"%inf",sep=""),
                    paste("ICB0",conf_int*100,"%sup",sep=""),
                    paste("ICB1",conf_int*100,"%inf",sep=""),
                    paste("ICB1",conf_int*100,"%sup",sep=""),
                    paste("ICB2",conf_int*100,"%inf",sep=""),
                    paste("ICB2",conf_int*100,"%sup",sep=""),
                    paste("ICB3",conf_int*100,"%inf",sep=""),
                    paste("ICB3",conf_int*100,"%sup",sep=""),
                    "Group")
    if(robust) colnames(RES)<<-c("B0","B1","B2","B3","R^2",
                               paste("ICrobustB0",conf_int*100,"%inf",sep=""),
                               paste("ICrobustB0",conf_int*100,"%sup",sep=""),
                               paste("ICrobustB1",conf_int*100,"%inf",sep=""),
                               paste("ICrobustB1",conf_int*100,"%sup",sep=""),
                               paste("ICrobustB2",conf_int*100,"%inf",sep=""),
                               paste("ICrobustB2",conf_int*100,"%sup",sep=""),
                               paste("ICrobustB3",conf_int*100,"%inf",sep=""),
                               paste("ICrobustB3",conf_int*100,"%sup",sep=""),
                               "Group")
  }

  return(RES)

}


